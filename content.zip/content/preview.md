---
title: "预览模块"
metaTitle: "页面描述标题-"
metaDescription: "页面内容描述"
---

The following is a code block with JavaScript language syntax highlighting.

Supports multiple languages.

The following is a code block with diff. Lines with `+` highlighted in green shade indicating an addition. Lines with `-` highlighted in red shade indicating a deletion.


## 在线编辑
![avatar](http://baidu.com/pic/doge.png)


## 测试编辑标题

```javascript react-live=true
<button className={'btn btn-default'}>Change my text</button>
```